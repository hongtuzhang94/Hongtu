CREATE DATABASE "TEAM_12";
Go

USE "TEAM_12";

CREATE SCHEMA Customer;
CREATE SCHEMA Sales;
CREATE SCHEMA Info;
CREATE SCHEMA Supplier;
CREATE SCHEMA Product;
GO

/* 
 * 
 * Database implementation 
 * 
 * */

/* constraints function */
CREATE FUNCTION Customer.CreditCardCheck (@methodCode int, @creditCardNum varchar(20))
RETURNS bit
AS 
BEGIN
    IF @methodCode = 1 AND @creditCardNum IS NULL
    	RETURN 0
    RETURN 1
END;

CREATE FUNCTION Sales.CartItemCount(@customerId int)
RETURNS int
AS 
BEGIN
    DECLARE @itemCount int =
    (SELECT COUNT(Cart_Items_Id) 
     FROM Customer.Customer_Shopping_Cart_Items 
     WHERE Customer_Id = @customerId)
    SET @itemCount = ISNULL(@itemCount, 0)
    RETURN @itemCount
END;

CREATE FUNCTION Sales.IsValidQuantity(@productId int, @quantity int)
RETURNS bit
AS 
BEGIN
    IF @quantity BETWEEN 1 AND 
    ( SELECT Inventory_Quantity FROM Product.Products WHERE Product_Id = @productId)
    	RETURN 1
    RETURN 0
END;


/* calculated column */
-- calculate Item_Total_Price
CREATE FUNCTION Sales.CalItemTotalPrice(@Order_Id int)
RETURNS money
AS
BEGIN
	DECLARE @Item_Total_Price money
	SELECT @Item_Total_Price = SUM(LineTotal)
		FROM 
		   (SELECT (Order_Item_Quantity * Order_Item_Price) AS LineTotal
		    FROM Sales.Order_Items
		    WHERE Order_Id = @Order_Id) AS temp
	SET @Item_Total_Price = ISNULL(@Item_Total_Price, 0)
	RETURN @Item_Total_Price
END

-- calculate Shipment_Fee
CREATE FUNCTION Sales.CalShipFee(@Order_Id int)
RETURNS money
AS
BEGIN
	DECLARE @Shipment_Fee money
	DECLARE @subtotal money =
	   (SELECT Item_Total_Price
	    FROM Sales.Orders
	    WHERE Order_Id = @Order_Id)
	IF @subtotal >= 50
	    SET @Shipment_Fee = 0
	ELSE SET @Shipment_Fee = 6
    RETURN @Shipment_Fee
END

-- calculate Order_Total_Price
CREATE FUNCTION Sales.CalOrderPrice(@Order_Id int)
RETURNS money
AS
BEGIN
	DECLARE @Order_Total_Price money =
	   (SELECT o.Item_Total_Price + s.Shipment_Fee
	    FROM Sales.Orders o INNER JOIN Sales.Shipments s
	    ON o.Order_Id = s.Order_Id 
	    WHERE o.Order_Id = @Order_Id)
    RETURN @Order_Total_Price
END


/* create tables */
CREATE TABLE Customer.Customers 
	(
	Customer_Id int NOT NULL PRIMARY KEY,
	First_Name varchar(30) NOT NULL, 
	Last_Name varchar(30) NOT NULL,
	Gender varchar(5) NOT NULL,
	Date_Of_Birth date NOT NULL,
	Age AS DATEDIFF(hour,Date_Of_Birth,GETDATE())/8766,
	Phone_Number varchar(20) NOT NULL,
	Email_Address varchar(50) NOT NULL UNIQUE
	);

CREATE TABLE Info.Addresses 
	(
	Address_Id int NOT NULL PRIMARY KEY,
	Street_Number varchar(50) NOT NULL, 
	City varchar(20) NOT NULL,
	State varchar(5) NOT NULL,
	Zip_Code varchar(10) NOT NULL,
	);

CREATE TABLE Customer.Customer_Addresses 
  	(
	Customer_Id int NOT NULL
		REFERENCES Customer.Customers(Customer_Id),
	Address_Id int NOT NULL
		REFERENCES Info.Addresses(Address_Id),
		CONSTRAINT PK_CustomerAddresses PRIMARY KEY CLUSTERED (Customer_Id, Address_Id)
	);

CREATE TABLE Sales.Payment_Methods
	(
	Payment_Method_Code int NOT NULL PRIMARY KEY,
	Payment_Method_Name varchar(50) NOT NULL, 
	Payment_Method_Description varchar(200),
	);


CREATE TABLE Customer.Customer_Payment_Methods 
	(
	PaymentInfo_Id int NOT NULL PRIMARY KEY,
	Customer_Id int NOT NULL
		REFERENCES Customer.Customers(Customer_Id),
	Payment_Method_Code int NOT NULL
		REFERENCES Sales.Payment_Methods(Payment_Method_Code),
	Credit_Card_Number varchar(20),
	Account_Number varchar(100)
	);	

CREATE TABLE Product.Product_Categories
	(
	Product_Category_Code varchar(40) NOT NULL PRIMARY KEY,
	Product_Category_Name varchar(40),
	Product_Category_Description varchar(200)
	);

CREATE TABLE Product.Products
	(
	Product_Id int NOT NULL PRIMARY KEY,
	Product_Category_Code varchar(40) NOT NULL
		REFERENCES Product.Product_Categories(Product_Category_Code),
	Product_Name varchar(100) NOT NULL,
	Product_Price float NOT NULL CHECK (Product_Price >= 0),
	Product_Color varchar(40),
	Product_Picture varchar(250),
	Inventory_Quantity varchar(40) NOT NULL CHECK (Inventory_Quantity >= 0),
	Product_Description varchar(max)
	);

CREATE TABLE Customer.Customer_Shopping_Cart_Items
	(
	Cart_Items_Id int NOT NULL PRIMARY KEY,
	Customer_Id int NOT NULL 
		REFERENCES Customer.Customers(Customer_Id),
	Product_Id int NOT NULL
		REFERENCES Product.Products(Product_Id),
	Cart_Item_Quantity int NOT NULL CHECK ( Cart_Item_Quantity > 0),
	Last_Modified_Date datetime DEFAULT Current_Timestamp,
	Item_Expire_Date AS DATEADD(day, 100, Last_Modified_Date)
	);

CREATE TABLE Customer.Customer_Reviews
	(
	Review_Id int NOT NULL PRIMARY KEY,
	Customer_Id int NOT NULL
		REFERENCES Customer.Customers(Customer_Id),
	Product_id int NOT NULL
		REFERENCES Product.Products(Product_Id),
	Review_Timestamp datetime DEFAULT Current_Timestamp,
	Review_Content varchar(max),
	Rating int CHECK (Rating BETWEEN 0 AND 5)
	);

CREATE TABLE Supplier.Suppliers
	(
	Supplier_Id int NOT NULL PRIMARY KEY,
	Supplier_Name varchar(100) NOT NULL,
	Phone_Number varchar(20) NOT NULL,
	Email_Address varchar(100) NOT NULL
	);

CREATE TABLE Supplier.Supplier_Addresses
	(
	Address_Id int NOT NULL
		REFERENCES Info.Addresses(Address_Id),
	Supplier_Id int NOT NULL
		REFERENCES Supplier.Suppliers(Supplier_Id),
		CONSTRAINT PK_SupplierAddresses PRIMARY KEY CLUSTERED (Supplier_Id, Address_Id)
	);

CREATE TABLE Supplier.Supply_Items
	(
	Supply_Item_Id int NOT NULL PRIMARY KEY,
	Supplier_Id int NOT NULL
		REFERENCES Supplier.Suppliers(Supplier_Id),
	Product_Id int NOT NULL
		REFERENCES Product.Products(Product_Id),
	Expire_Date date NOT NULL
	);

CREATE TABLE Sales.Order_Status
	(    
	Order_Status_Code int NOT NULL PRIMARY KEY,
	Order_Status_Name varchar(30) NOT NULL,
	Order_Status_Description varchar(500)
	);

CREATE TABLE Sales.Orders
	(    
	Order_Id int NOT NULL PRIMARY KEY,
	Customer_Id int NOT NULL
		REFERENCES Customer.Customers(Customer_Id),
	Order_Status_Code int NOT NULL 
		REFERENCES Sales.Order_Status(Order_Status_Code),
	Order_Placed_Date date NOT NULL DEFAULT GETDATE(),
	Item_Total_Price AS (Sales.CalItemTotalPrice(Order_Id)),
	Order_Total_Price AS  (Sales.CalOrderPrice(Order_Id))
	);

CREATE TABLE Sales.Order_Items
	(    
	Order_Item_Id int NOT NULL PRIMARY KEY,
	Product_Id int NOT NULL
		REFERENCES Product.Products(Product_Id),
	Order_Id int NOT NULL 
		REFERENCES Sales.Orders(Order_Id),
	Order_Item_Quantity int NOT NULL,
	Order_Item_Price float NOT NULL
	);

CREATE TABLE Sales.Shipments
	(    
	Shipment_Id int NOT NULL PRIMARY KEY,
	Order_Id int NOT NULL
		REFERENCES Sales.Orders(Order_Id),
	Address_Id int NOT NULL
		REFERENCES Info.Addresses(Address_Id),
	Tracking_Number int,
	Shipment_Date date,
	Delivery_Date date,
	Shipment_Fee AS (Sales.CalShipFee(Order_Id))
	);


/* create triggers */
CREATE TRIGGER tr__LastModifiedCartItem
ON Customer.Customer_Shopping_Cart_Items
AFTER UPDATE
AS
BEGIN
    IF (SELECT COUNT(*) FROM Inserted) > 0
    BEGIN
	    UPDATE Customer.Customer_Shopping_Cart_Items
		SET Last_Modified_Date = CURRENT_TIMESTAMP
		WHERE Cart_Items_Id = 
            (SELECT i.Cart_Items_Id 
             FROM Inserted AS i
             JOIN Customer.Customer_Shopping_Cart_Items AS sci
             ON i.Cart_Items_Id = sci.Cart_Items_Id)
    END
END


/* insert data */
INSERT Customer.Customers
	VALUES(5401, 'Gail', 'Erickson', 'F', '1992-05-01', '122-555-0189', 'gail.e@team12-shopping.com'),
		  (5402, 'Riley', 'Goldberg', 'F','1983-02-15', '697-555-0142', 'riley.g@team12-shopping.com'),
		  (5403, 'Michael', 'Raheem', 'M', '1987-03-10', '486-555-0150', 'michael.r@team12-shopping.com'),
		  (5404, 'Janice', 'Galvin', 'F', '1996-08-27', '719-555-0181', 'janice.g@team12-shopping.com'),
		  (5405, 'Mary', 'Dempsey', 'F', '1994-06-21', '510-555-0121', 'mary.d@team12-shopping.com'),
		  (5406, 'Vanessa', 'Brown', 'F', '1982-09-04', '970-555-0118', 'vanessa.b@team12-shopping.com'),
		  (5407, 'Cristian', 'Petculescu', 'F', '1997-11-24', '202-555-0151', 'cristian.p@team12-shopping.com'),
		  (5408, 'Tom', 'Hunter', 'M', '1991-12-06', '999-555-0155', 'tom.h@team12-shopping.com'),
		  (5409, 'Frank', 'Martine', 'M', '1995-08-05', '559-555-0175', 'frank.m@team12-shopping.com'),
		  (5410, 'Carole', 'Poland', 'F', '1998-04-17', '164-555-0114', 'carole.p@team12-shopping.com');

INSERT Info.Addresses
	VALUES (2001, '636 Vine Hill Way', 'Portland', 'OR', '97205'),
		   (2002, '6657 Sand Pointe Lane', 'Seattle', 'WA', '98104'),
		   (2003, '9178 Jumping St.', 'Dallas', 'TX', '75201'),
		   (2004, '5725 Glaze Drive', 'San Francisco', 'CA', '94109'),
		   (2005, '4151 Olivera', 'Atlanta', 'GA', '30308'),
		   (2006, '9056 Mount Dr', 'Chicago', 'IL', '60610'),
		   (2007, '2596 Big Canyon Road', 'New York', 'NY', '10007'),
		   (2008, '683 Larch Ct.', 'Salt Lake City', 'UT', '84101'),
		   (2009, '9903 Highway 6 South', 'Houston', 'TX', '77003'),
		   (2010, '90 Sunny Ave', 'Berkeley', 'CA', '94704'),
 		   (5325, '9265 La Paz', 'Lakewood', 'IL', '98011'),
		   (5326, '1902 Santa Cruz', 'Bellevue', 'CA', '95041'),
		   (5327, '2115 Passing', 'Concord', 'DC', '98272'),
		   (5328, '9745 Bonita Ct.', 'Salem', 'FL', '97301'),
		   (5329, '6871 Thornwood Dr.', 'Melbourne', 'CA','94081'),
		   (5330, '4311 Clay Rd', 'Burnaby', 'MA', '98324'),
		   (5331, '9530 Vine Lane', 'Montreal', 'NY', '92118'),
		   (5332, '7772 Golden Meadow', 'Ottawa', 'NV', '99202'),
		   (5333, '3770 Viewpoint Ct', 'Wood Dale', 'RI', '97301'),
		   (5334, '2141 Delaware Ct.', 'Saint Louis', 'WA', '97005'),
		   (5335, '8629 Pepper Place', 'Killeen','CA', '96032');

INSERT Customer.Customer_Addresses
	VALUES(5401,5325),
		  (5402,5326),
		  (5403,5327),
		  (5404,5328),
		  (5405,5329),
		  (5401,5330),
		  (5406,5326),
		  (5407,5331),
		  (5408,5332),
		  (5409,5333),
		  (5410,5334),
		  (5404,5335);
		 
INSERT Sales.Payment_Methods(Payment_Method_Code, Payment_Method_Name)
	VALUES(1, 'Credit Card'),
		  (2, 'PayPal'),
		  (3, 'Venmo'),
		  (4, 'Amazon Payments'),
		  (5, 'Google Pay'),
		  (6, 'Apple Pay'),
		  (7, 'Wechat Pay'),
		  (8, 'Stripe'),
		  (9, 'Payoneer'),
		  (10, 'Payza');

INSERT Customer.Customer_Payment_Methods
	VALUES(4201, 5401, 1, '11111063290504', null),
		  (4202, 5401, 1, '11116857559490', null),
		  (4203, 5402, 1, '55556135765472', null),
		  (4204, 5404, 1, '77773035177913', null),
		  (4205, 5405, 1, '55556891733409', null),
		  (4206, 5406, 1, '77778258299726', null),
		  (4207, 5408, 1, '77774261153866', null),
		  (4208, 5409, 1, '55553177744050', null),
		  (4209, 5410, 1, '33338418715127', null),
		  (4210, 5404, 1, '33338669078698', null);

INSERT Product.Product_Categories
	VALUES('A01','baby food','0~4'),
		  ('A02','dietary supplement','diet food'),
		  ('A03','skin care',null),
		  ('A04','cleaning supplies','made in china'),
		  ('A05','grocery','housewife'),
		  ('A06','pet supplements','pet'),
		  ('A07','wine','alcohol'),
		  ('A08','pharmacy','need prescription'),
		  ('A09','candy','sweet'),
		  ('A10','snack','for all age');
		 
INSERT Product.Products
	VALUES (4001, 'A01','Apple Avocado', 10, null, null, 100, 'nutritional'),
		   (4002, 'A02', 'Animal Juiced Aminos', 25.94, null, null, 100, 'black'),
   		   (4003, 'A03', 'Belei', 55, null, null, 100, 'green'),
		   (4004, 'A04', 'Mrs. Meyer', 15.98, null, null, 100, 'bottle'),
		   (4005, 'A05', 'Cheez-It', 13.98, null, null, 100, 'crispy'),
	       (4006, 'A06', 'JustFoodForDogs', 23.95, null, null, 100, 'dog'),
		   (4007, 'A07', 'Coravin', 799.95, null, null, 100, 'wine preservation tools'),
		   (4008, 'A08', 'halls', 2.79, null, null, 100, 'vitamin C'),
		   (4009, 'A09', 'Tic Tac', 27.44, null, null, 100, 'coca cola'),
		   (4010, 'A10', 'CLIF KID ZBAR', 21.49, null, null, 100, 'energy bars'),
		   (4011, 'A09', 'Twizzlers Bulk Strawberry', 11.99, null, null, 80, 'Licorice Candy, 5 Pounds'),
		   (4012, 'A09', 'Skittles Original Candy', 9.95, null, null, 150,'colorful SKITTLES Candy is perfect for craft projects');

INSERT Customer.Customer_Shopping_Cart_Items(Cart_Items_Id, Customer_Id, Product_Id, Cart_Item_Quantity, Last_Modified_Date)
	VALUES(6000,5401,4008,10,'2020-01-01'),
		  (6001,5402,4002,2,'2020-04-30'),
		  (6002,5402,4005,5,'2020-05-01'),
		  (6003,5404,4007,1,'2020-05-02'),
		  (6004,5405,4006,3,'2020-05-01'),
		  (6005,5405,4004,3,'2020-06-20');
		  
INSERT Customer.Customer_Shopping_Cart_Items(Cart_Items_Id, Customer_Id, Product_Id, Cart_Item_Quantity)
	VALUES(6006,5401,4001,20),
		  (6007,5402,4001,20),
		  (6008,5403,4002,20),
		  (6009,5404,4005,20),
		  (6010,5405,4007,20),
		  (6011,5406,4001,20),
		  (6012,5407,4002,20),
		  (6013,5407,4005,20),
		  (6014,5407,4008,20),
		  (6015,5407,4009,20);

INSERT Customer.Customer_Reviews(Review_Id, Customer_Id, Product_Id, Review_Content, Rating)
	VALUES(7001,5401,4001,'nice',5),
		  (7002,5402,4002,'bad',1),
		  (7003,5403,4003,'just so so',3),
		  (7004,5404,4004,'nice',4),
		  (7006,5406,4006,'I do not like it',2),
		  (7007,5407,4007,'nice',5),
		  (7008,5408,4008,'I will not but it again',3),
		  (7009,5409,4009,'nice',5),
		  (7010,5401,4002,'nice',4),
		  (7011,5404,4003,'nice',4),
		  (7012,5404,4009,'nice',4),
		  (7013,5401,4005,'so so',3),
		  (7014,5407,4011,'ok', 4),
		  (7015,5404,4012,'perfect', 5);
	 

INSERT Supplier.Suppliers
	VALUES (1001, 'Best Baby Food', '612-555-0100', 'bestbf@work.com'),
		   (1002, 'World Dietary Supplement Shop', '122-555-0189', 'Worlddss@work.com'),
		   (1003, 'Beautiful Skin Care Store', '473-555-0117', 'Beautifulscs@work.com'),
		   (1004, 'Great Cleaning Supplies', '970-555-0138', 'Greatcs@work.com'),
		   (1005, 'My Love Grocery', '708-555-0141', 'myloveg@work.com'),
		   (1006, 'Choice Pet Supplements', '314-555-0113', 'Choiceps@work.com'),
		   (1007, 'Total Wine shop', '206-555-0180', 'Totalws@work.com'),
		   (1008, 'Healthy Pharmacy', '508-555-0165', 'healthyp@work.com'),
		   (1009, 'Sweet Candy Home', '846-555-0157', 'sweetch@work.com'),
		   (1010, 'Rainbow Snack Shop', '727-555-0115', 'Rainbowss@work.com');
		   
INSERT Supplier.Supplier_Addresses
	VALUES (2001, 1002),
		   (2002, 1005),
		   (2003, 1008),
		   (2004, 1009),
		   (2005, 1001),
		   (2006, 1007),
		   (2007, 1003),
		   (2008, 1006),
		   (2009, 1010),
		   (2010, 1004);
		   
INSERT Supplier.Supply_Items
	VALUES (3001, 1002, 4002, '2021-12-31'),
		   (3002, 1005, 4005, '2020-09-30'),
		   (3003, 1003, 4003, '2022-03-01'),
		   (3004, 1001, 4001, '2020-10-11'),
		   (3005, 1010, 4010, '2021-06-30'),
		   (3006, 1008, 4008, '2021-10-31'),
		   (3007, 1007, 4007, '2022-03-15'),
		   (3008, 1004, 4004, '2021-09-28'),
		   (3009, 1009, 4009, '2023-01-10'),
		   (3010, 1006, 4006, '2021-08-31');

INSERT Sales.Order_Status 
    VALUES (9011, 'Outstanding Payment', 'Unpaid Orders'),
    	   (9012, 'Pending', 'The order is generated but haven’t been processed yet. Customers can cancel the order.'),
           (9013, 'Processing', 'Working on the order, customers cannot cancel at this status'),
           (9014, 'Shipped', 'Order has been shipped'),
           (9015, 'Delivered', 'Delivered'),
           (9016, 'Canceled', 'Order has been canceled');
          
INSERT Sales.Orders (Order_Id, Customer_Id, Order_Status_Code, Order_Placed_Date)
    VALUES (8011, 5401, 9015, '2020-01-10'),
           (8012, 5402, 9015, '2020-01-15'),
           (8013, 5403, 9015, '2020-01-31'),
           (8014, 5404, 9015, '2020-02-26'),
           (8015, 5405, 9016, '2020-02-28'),
           (8016, 5406, 9015, '2020-02-28'),
           (8017, 5407, 9015, '2020-03-02'),
           (8018, 5408, 9015, '2020-04-07'),
           (8019, 5409, 9014, '2020-08-06'),
           (8020, 5410, 9012, '2020-08-08'),
           (8021, 5404, 9015, '2020-06-07'), 
           (8022, 5404, 9015, '2020-06-13'),
           (8023, 5401, 9015, '2020-06-14');
          
INSERT Sales.Order_Items
    VALUES (3011, 4001, 8011, 2, 10),
           (3012, 4002, 8012, 10, 25.94),
           (3013, 4003, 8013, 2, 55),
           (3014, 4004, 8014, 1, 15.98),
           (3015, 4005, 8015, 1, 13.98),
           (3016, 4006, 8016, 1, 23.95),
           (3017, 4007, 8016, 12, 799.85),
           (3018, 4008, 8018, 1, 2.79),
           (3019, 4009, 8019, 3, 27.44),
           (3020, 4010, 8020, 2, 21.49),
           (3021, 4002, 8011, 1, 25.94),
           (3022, 4003, 8021, 1, 55), 
           (3023, 4009, 8022, 5, 27.44),
           (3024, 4005, 8023, 3, 13.98),
           (3025, 4001, 8023, 4, 10),
           (3026, 4011, 8017, 5, 11.99),
    	   (3027, 4012, 8017, 2, 9.95),
    	   (3028, 4012, 8021, 10, 9.95);

INSERT Sales.Shipments(Shipment_Id, Order_Id, Address_Id, Tracking_Number, Shipment_Date, Delivery_Date)
    VALUES (7011, 8011, 5325, 40701801, '2020-01-11', '2020-01-15'),
           (7012, 8012, 5326, 40702802, '2020-01-16', '2020-01-21'),
           (7013, 8013, 5327, 40703803, '2020-02-01', '2020-02-06'),
           (7014, 8014, 5328, 40704804, '2020-02-27', '2020-03-03'),
           (7016, 8016, 5326, 40706806, '2020-03-01', '2020-03-06'),
           (7017, 8017, 5331, 40707807, '2020-03-03', '2020-03-08'),
           (7018, 8018, 5335, 40708808, '2020-04-08', '2020-04-13'),
           (7019, 8019, 5333, 40709809, '2020-05-31', null),
           (7021, 8021, 5335, 40701810, '2020-06-08', '2020-06-12'),
           (7022, 8022, 5335, 40702811, '2020-06-14', '2020-06-18'),
           (7023, 8023, 5330, 40701812, '2020-06-15', '2020-06-20');
          
 INSERT Sales.Shipments(Shipment_Id, Order_Id, Address_Id)
    VALUES (7015, 8015, 5329),
    	   (7020, 8020, 5334);
          
          
/* Add table-level constraints */
-- If a credit card payment is inserted, credit card number cannot be null
ALTER TABLE Customer.Customer_Payment_Methods 
ADD CONSTRAINT CK__Constrain__CreditCardCheck
CHECK (Customer.CreditCardCheck(Payment_Method_Code, Credit_Card_Number) = 1 );

-- The item quantity in an order must between 1 and the inventory quantity of the item
ALTER TABLE Sales.Order_Items
ADD CONSTRAINT CK__Constrain__OrderQuantity
CHECK (Sales.IsValidQuantity(Product_Id, Order_Item_Quantity) = 1 );          
     
-- Each customer can have at most 100 products in shopping cart
ALTER TABLE Customer.Customer_Shopping_Cart_Items
ADD CONSTRAINT CK__Constrain__CartItemCount
CHECK (Sales.CartItemCount(Customer_Id) <= 100);          


/* delete expire items in shopping cart */
DELETE FROM Customer.Customer_Shopping_Cart_Items 
WHERE Item_Expire_Date < GETDATE();



/* 
 * 
 * test 
 * 
 * */

/* check tables(test calculated column) */
SELECT * FROM Customer.Customers
SELECT * FROM Customer.Customer_Payment_Methods
SELECT * FROM Customer.Customer_Shopping_Cart_Items
SELECT * FROM Customer.Customer_Reviews
SELECT * FROM Customer.Customer_Addresses
SELECT * FROM Product.Product_Categories
SELECT * FROM Product.Products
SELECT * FROM Supplier.Suppliers 
SELECT * FROM Supplier.Supply_Items
SELECT * FROM Supplier.Supplier_Addresses
SELECT * FROM Sales.Order_Status
SELECT * FROM Sales.Orders
SELECT * FROM Sales.Order_Items
SELECT * FROM Sales.Shipments
SELECT * FROM Sales.Payment_Methods
SELECT * FROM Info.Addresses


/* constraint tests */
-- insert a credit card payment without credit card number
INSERT Customer.Customer_Payment_Methods 
	VALUES(111111111, 5401, 1, null)

-- invalid quantity in shopping cart
INSERT Customer.Customer_Shopping_Cart_Items(Cart_Items_Id, Customer_Id, Product_Id, Cart_Item_Quantity)
	VALUES(111111,5401,4008,0)
INSERT Customer.Customer_Shopping_Cart_Items(Cart_Items_Id, Customer_Id, Product_Id, Cart_Item_Quantity)
	VALUES(111111,5401,4008,-100)

-- under rule: no more 100 items in shopping cart, insertion succeeded
INSERT Customer.Customer_Shopping_Cart_Items(Cart_Items_Id, Customer_Id, Product_Id, Cart_Item_Quantity)
	VALUES(111111,5407,4008,2)
SELECT * FROM Customer.Customer_Shopping_Cart_Items 
DELETE FROM Customer.Customer_Shopping_Cart_Items WHERE Cart_Items_Id = 111111
	
-- use (no more 4 items in shopping cart) constraint
ALTER TABLE Customer.Customer_Shopping_Cart_Items
ADD CONSTRAINT CK__Constrain__CartItemCount_TEST
CHECK (Sales.CartItemCount(Customer_Id) <= 4);           
-- insertion failed
INSERT Customer.Customer_Shopping_Cart_Items(Cart_Items_Id, Customer_Id, Product_Id, Cart_Item_Quantity)
	VALUES(111112,5407,4008,2)
-- drop test constraint
ALTER TABLE Customer.Customer_Shopping_Cart_Items
DROP CONSTRAINT CK__Constrain__CartItemCount_TEST

-- insertion failed if order quantity smaller than iventory quantityß
INSERT Sales.Order_Items(Order_Item_Id, Product_Id, Order_Id, Order_Item_Quantity, Order_Item_Price)
    VALUES (1111111, 4001, 8011, 200, 10);

   
/* trigger test */
-- last modified date and expire date changed after update
UPDATE Customer.Customer_Shopping_Cart_Items
SET Cart_Item_Quantity = 40
WHERE Cart_Items_Id = 6007;
SELECT * FROM Customer.Customer_Shopping_Cart_Items 





/* 
 * 
 * query 
 * 
 * */
-- count shopping cart items for each customer
SELECT DISTINCT c.Customer_Id, 
	Sales.CartItemCount(c.Customer_Id) AS [item_Count_In_Cart]
FROM Customer.Customers c 
LEFT JOIN Customer.Customer_Shopping_Cart_Items sci
ON c.Customer_Id = sci.Customer_Id 

-- get shipment and order status
SELECT os.Order_Status_Name AS [Order_Status], s.* 
FROM Sales.Shipments s
JOIN Sales.Orders o 
ON s.Order_Id = o.Order_Id 
JOIN Sales.Order_Status os 
ON o.Order_Status_Code = os.Order_Status_Code 

-- get customers who have items in shopping cart that expire in 10 days
SELECT c2.Customer_Id,c2.Email_Address,sci2.Product_Id, p.Product_Name, sci2.Item_Expire_Date
FROM Customer.Customers c2 
JOIN Customer.Customer_Shopping_Cart_Items sci2
ON c2.Customer_Id = sci2.Customer_Id 
JOIN Product.Products p 
ON sci2.Product_Id = p.Product_Id 
WHERE GETDATE() > DATEADD(day,-10,sci2.Item_Expire_Date);




/* 
 * 
 * views and reports
 * 
 * */
CREATE VIEW vwProductSalesReport
  AS
    WITH temp 
  	AS (
  	 SELECT Product_Id, AVG(CAST(Rating AS DECIMAL(3,2))) AS [Average Rating]
     FROM Customer.Customer_Reviews
     GROUP BY Product_Id
     )
  SELECT DISTINCT oi.Product_Id, p.Product_Name, pc.Product_Category_Name, t.[Average Rating],
      SUM(oi.Order_Item_Quantity) AS [Total Sold Quantity],
      RANK() OVER (PARTITION BY pc.Product_Category_Name 
      ORDER BY SUM(oi.Order_Item_Quantity) DESC,t.[Average Rating] DESC) AS [Rank]
  FROM Sales.Order_Items oi
  INNER JOIN Product.Products p
  ON p.Product_Id = oi.Product_Id
  INNER JOIN Product.Product_Categories pc
  ON p.Product_Category_Code = pc.Product_Category_Code
  INNER JOIN Sales.Orders o 
  ON oi.Order_Id = o.Order_Id
  LEFT OUTER JOIN TEMP t
  ON oi.Product_Id = t.Product_Id
  WHERE YEAR(o.Order_Placed_Date) = 2020 AND o.Order_Status_Code NOT IN (9011, 9012, 9016)
  GROUP BY oi.Product_Id, p.Product_Name, pc.Product_Category_Name, t.[Average Rating]
  HAVING SUM(oi.Order_Item_Quantity) IS NOT NULL;
 
-- Report no.1: 2020 Product Sales Report (TOP 100 in each category)   
SELECT *
FROM vwProductSalesReport
WHERE [Rank] < 100
ORDER BY Product_Category_Name, [Total Sold Quantity] DESC;

	
CREATE VIEW vwStateStats
AS
(
SELECT o.Customer_Id, a.State, COUNT(o.Order_Id) as [order_Num],
	  RANK() OVER (PARTITION BY o.Customer_Id
      ORDER BY COUNT(o.Order_Id) DESC) AS [Rank]
FROM (SELECT * FROM Sales.Orders
	  WHERE YEAR(Order_Placed_Date) = 2020 
		AND (Order_Status_Code NOT IN (9011, 9012, 9016))
	  ) as o
JOIN Sales.Shipments s 
ON o.Order_Id = s.Order_Id
JOIN Info.Addresses a 
ON s.Address_Id = a.Address_Id
GROUP BY a.State, o.Customer_Id
);


CREATE VIEW vwOrderStats
AS
(
	SELECT o.Customer_Id, COUNT(Order_Id) AS [Order_Number], 
		SUM(Order_Total_Price) AS [Total_Due],
		STUFF((SELECT ', '+ RTRIM(Order_Id)
			FROM Sales.Orders o2
			WHERE o.Customer_Id = o2.Customer_Id
			ORDER BY Order_Id 
			FOR XML PATH('')),1,2,'') AS [Orders_Id]
	FROM Sales.Orders o
	WHERE YEAR(Order_Placed_Date) = 2020 
		AND (Order_Status_Code NOT IN (9011, 9012, 9016))
	GROUP BY o.Customer_Id 
);


CREATE VIEW vwOrderItemStats
AS
(
SELECT c.Customer_Id, pc.Product_Category_Code, pc.Product_Category_Name, 
	COUNT(oi.Order_Item_Id) AS [Item_Number],
	RANK() OVER (PARTITION BY c.Customer_Id
      ORDER BY COUNT(oi.Order_Item_Id) DESC) AS [Rank]
from Customer.Customers c 
JOIN (SELECT * FROM Sales.Orders
	  WHERE YEAR(Order_Placed_Date) = 2020 
		AND (Order_Status_Code NOT IN (9011, 9012, 9016))
	  ) as o 
ON c.Customer_Id = o.Customer_Id
JOIN Sales.Order_Items oi 
ON o.Order_Id = oi.Order_Id 
JOIN Product.Products p 
ON oi.Product_Id = p.Product_Id 
JOIN Product.Product_Categories pc 
ON p.Product_Category_Code = pc.Product_Category_Code 
GROUP BY c.Customer_Id, pc.Product_Category_Code, pc.Product_Category_Name
)


CREATE VIEW vwCustomerReport 
AS
(
SELECT DISTINCT DENSE_RANK() OVER (ORDER BY order_stats.Total_Due DESC) AS [Rank],
	c2.Customer_Id, c2.First_Name, c2.Gender, c2.Age,
	STUFF((SELECT ', '+ RTRIM(State)
		FROM vwStateStats sts2
		WHERE c2.Customer_Id = sts2.Customer_Id AND sts2.Rank = 1
		ORDER BY State 
		FOR XML PATH('')),1,2,'') AS [Most_Shipped_To],
	order_stats.Order_Number,order_stats.Total_Due, order_stats.Orders_Id,
	STUFF((SELECT ', '+ RTRIM(Product_Category_Name)
		FROM vwOrderItemStats ois2
		WHERE c2.Customer_Id = ois2.Customer_Id AND ois2.Rank = 1
		ORDER BY Product_Category_Code 
		FOR XML PATH('')),1,2,'') AS [Most_Purchased_Category]
FROM Customer.Customers c2 
JOIN vwStateStats sts
ON c2.Customer_Id = sts.Customer_Id
JOIN vwOrderStats order_stats
ON c2.Customer_Id = order_stats.Customer_Id
JOIN vwOrderItemStats ois
ON c2.Customer_Id = ois.Customer_Id
)

-- Report no.2: Customer Report(TOP 5 of total due)
SELECT * 
FROM vwCustomerReport 
WHERE [Rank] <= 5

-- Customer Report(All)
SELECT * 
FROM vwCustomerReport 


/* clean statements */       
DROP TABLE Customer.Customer_Addresses 
DROP TABLE Customer.Customer_Payment_Methods 
DROP TABLE Customer.Customer_Shopping_Cart_Items
DROP TABLE Customer.Customer_Reviews
DROP TABLE Supplier.Supplier_Addresses
DROP TABLE Supplier.Supply_Items

DROP TABLE Sales.Shipments
DROP TABLE Sales.Order_Items
DROP TABLE Sales.Orders

DROP TABLE Customer.Customers 
DROP TABLE Sales.Payment_Methods

DROP TABLE Product.Products
DROP TABLE Product.Product_Categories

DROP TABLE Supplier.Suppliers
DROP TABLE Sales.Order_Status

DROP TABLE Info.Addresses 

ALTER TABLE Customer.Customer_Payment_Methods 
DROP CONSTRAINT CK__Constrain__CreditCardCheck

ALTER TABLE Sales.Order_Items
DROP CONSTRAINT CK__Constrain__OrderQuantity
     
ALTER TABLE Customer.Customer_Shopping_Cart_Items
DROP CONSTRAINT CK__Constrain__CartItemCount

DROP FUNCTION Customer.CreditCardCheck
DROP FUNCTION Sales.CartItemCount
DROP FUNCTION Sales.IsValidQuantity
DROP FUNCTION Sales.CalItemTotalPrice
DROP FUNCTION Sales.CalShipFee
DROP FUNCTION Sales.CalOrderPrice

DROP VIEW vwProductSalesReport
DROP VIEW vwStateStats
DROP VIEW vwOrderStats
DROP VIEW vwOrderItemStats
DROP VIEW vwCustomerReport
